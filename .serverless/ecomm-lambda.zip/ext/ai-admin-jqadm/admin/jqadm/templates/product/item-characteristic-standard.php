<?php

/**
 * @license LGPLv3, http://opensource.org/licenses/LGPL-3.0
 * @copyright Aimeos (aimeos.org), 2016-2018
 */

$enc = $this->encoder();

?>
<div id="characteristic" class="row item-characteristic tab-pane fade" role="tabpanel" aria-labelledby="characteristic">
	<?= $this->get( 'characteristicBody' ); ?>
</div>
